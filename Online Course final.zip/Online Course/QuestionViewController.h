//
//  QuestionViewController.h
//  Online Course
//
//  Created by Yike Xue on 7/8/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuestionViewController : UIViewController <NSXMLParserDelegate, UITableViewDataSource, UITableViewDelegate>

@property (copy, nonatomic) NSString *userID;
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@property (weak, nonatomic) IBOutlet UITextView *questionLabel;
@property (weak, nonatomic) IBOutlet UITextField *answerLabel;

@end
