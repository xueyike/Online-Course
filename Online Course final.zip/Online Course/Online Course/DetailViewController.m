//
//  DetailViewController.m
//  Online Course
//
//  Created by Yike Xue on 7/6/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "DetailViewController.h"
#import "AppDelegate.h"
#import "QuestionViewController.h"

@interface DetailViewController ()

@property (strong, nonatomic) MPMoviePlayerController *streamPlayer;
@property (strong,nonatomic) NSURL *streamURL;

@end

@implementation DetailViewController {
    NSMutableData *responseData;
    bool check;
    NSString *user;
}

#pragma mark - Managing the detail item

- (void)setDetailItem:(Section *)newDetailItem {
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
            
        // Update the view.
        [self configureView];
    }
}

- (void)configureView {
    // Update the user interface for the detail item.

    if(_detailItem == nil){
        _streamURL = [NSURL URLWithString:@"http://localhost/OnlineCourse/video/Chapter00/section1/Ch00S1List.m3u8"];
        self.watchingLabel.text = @"You are watching: Chapter00/Section 1";
    }else{
        _streamURL = [NSURL URLWithString: _detailItem.url];
        self.watchingLabel.text = [NSString stringWithFormat:@"You are watching: %@/%@",_detailItem.chap.chapter_name,_detailItem.section_name];
    }
    
    self.videoView.frame = [UIScreen mainScreen].applicationFrame;
   
    
    self.streamPlayer = [[MPMoviePlayerController alloc] initWithContentURL:_streamURL];
    
    if([[UIApplication sharedApplication] statusBarOrientation]  == UIInterfaceOrientationLandscapeLeft || [[UIApplication sharedApplication] statusBarOrientation]  == UIInterfaceOrientationLandscapeRight)
    {
        [self.streamPlayer.view setFrame:CGRectMake(5,0, self.view.bounds.size.width-330, self.videoView.bounds.size.width*0.4)];
    }
    else if ([[UIApplication sharedApplication] statusBarOrientation]  == UIInterfaceOrientationPortrait || [[UIApplication sharedApplication] statusBarOrientation]  == UIInterfaceOrientationPortraitUpsideDown)
    {
        [self.streamPlayer.view setFrame:CGRectMake(0,0, self.view.bounds.size.width, self.videoView.bounds.size.width*0.5)];
    }
    self.streamPlayer.controlStyle = MPMovieControlStyleEmbedded;
     [[NSNotificationCenter defaultCenter] addObserver:self   selector:@selector(myMovieFinishedCallback:)    name:MPMoviePlayerPlaybackDidFinishNotification   object:self.streamPlayer];

    [self.videoView addSubview: self.streamPlayer.view];
    
    [self.streamPlayer prepareToPlay];
//    [self.streamPlayer play];
//    [self.streamPlayer pause];
    
}

-(void)myMovieFinishedCallback:(NSNotification*)notify
{
    
    MPMoviePlayerController* theMovie = [notify object];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMoviePlayerPlaybackDidFinishNotification
                                                  object:theMovie];
    if(user == nil){
        NSLog(@"Finish playing!");
    }else{
        NSString *mes;
        if(self.detailItem == nil){
            mes = @"Chapter00/section1: What do you learn from this chapter?";
        }else{
            mes = [NSString stringWithFormat:@"%@/%@: What do you learn from this chapter?",self.detailItem.chap.chapter_name,self.detailItem.section_name];
        }
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Question" message:mes delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"submit",nil];
        alert.alertViewStyle =  UIAlertViewStylePlainTextInput;
        UITextField * txt = [[UITextField alloc] init];
        txt.backgroundColor = [UIColor whiteColor];
        txt.frame = CGRectMake(alert.center.x+65,alert.center.y+48, 150,23);
        [alert addSubview:txt];
        [alert show];
    }
}


- (void)viewDidDisappear:(BOOL)animated {
//    NSLog(@"Full screen? %@",self.streamPlayer.fullscreen?@"YES":@"NO");
    if(!self.streamPlayer.fullscreen){
        [self.streamPlayer pause];
    }
    //else is expanding the screens, do not stop
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    user = appDelegate.userID;
    
    if(user == nil){
        self.navigationItem.rightBarButtonItem.title = @"Login";
        self.navigationItem.title = [NSString stringWithFormat:@"For more features, please login."];
        self.journalButton.hidden = YES;
        self.journalButton.enabled = NO;
    }else{
        self.navigationItem.rightBarButtonItem.title = @"Logout";
        self.navigationItem.title = [NSString stringWithFormat:@"Hi, %@.",user];
        self.journalButton.hidden = NO;
        self.journalButton.enabled = YES;
    }
    
    [self configureView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    if(toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight)
    {

        if(user == nil) {
            [self.videoView.subviews[0] setFrame:CGRectMake(5,0, self.view.bounds.size.width-10, self.videoView.bounds.size.width*0.58)];
        }else{
            [self.streamPlayer.view setFrame:CGRectMake(5,0, self.view.bounds.size.width-330, self.videoView.bounds.size.width*0.4)];
        }
        
    }
    else if (toInterfaceOrientation == UIInterfaceOrientationPortrait || toInterfaceOrientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        if(user == nil) {
            [self.videoView.subviews[0] setFrame:CGRectMake(0,0, self.view.bounds.size.width, self.videoView.bounds.size.width*0.5)];
        }else{
            [self.videoView.subviews[0] setFrame:CGRectMake(10,0, self.view.bounds.size.width+300, self.videoView.bounds.size.width*0.8)];
        }
        
    }
}

//#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:@"showJournal"]){
        QuestionViewController *destination = segue.destinationViewController;
        if ([destination respondsToSelector:@selector(setDelegate:)]) {
            [destination setValue:self forKey:@"delegate"];
        }
        if ([destination respondsToSelector:@selector(setUserID:)]) {
            [destination setValue:user forKey:@"userID"];
        }
    }
}

- (void)saveQuestion: (NSString *)answer {
    NSString *envelopeText=
    @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
    "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n"
    "  <soap12:Body>\n"
    "    <With_x0020_DateAnswer xmlns=\"http://tempuri.org/\">\n"
    "    <UserID>%@</UserID>/n"
    "    <QuestionID>%@</QuestionID>/n"
    "    <QuestionAnswer>%@</QuestionAnswer>/n"
    "    <DateAnswered>%@</DateAnswered>/n"
    "    </With_x0020_DateAnswer>\n"
    "  </soap12:Body>\n"
    "</soap12:Envelope>";
    
    NSString *chapNum;
    if(self.detailItem == nil){
        chapNum = @"0";
    }else{
        chapNum = [self.detailItem.chap.chapter_name substringFromIndex:7];
    }
    envelopeText = [NSString stringWithFormat:envelopeText,user,chapNum,answer,@""];
    NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *url=@"http://www.softwaremerchant.com/OnlineCourse.asmx";
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:50.0];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:envelope];
    [request setValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%lu",[envelope length]] forHTTPHeaderField:@"Content-Length"];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    if(connection){
        responseData=[NSMutableData data];
    }
    else
        NSLog(@"NSURLConnection initWithRequest: Failed to return a connection");
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response

{
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data

{
    [responseData appendData:data];
}


- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error

{
    NSLog(@"connection didFailWithError: %@ %@",
          error.localizedDescription,
          
          [error.userInfo objectForKey:NSURLErrorFailingURLStringErrorKey]);
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection

{
    // extract result using regular expression (only as an example)
    // this is not a good way to do it; should use XPath queries with XML DOM such as GDataXMLDocument
    NSString *responseText = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",responseText);
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self doParse:responseData];
    });
}

-(void)doParse:(NSData *)data{
    NSXMLParser *nsXmlParser=[[NSXMLParser alloc]initWithData:data];
    nsXmlParser.delegate = self;
    
    [nsXmlParser parse];
}

//implement protocol methods of NSXMLParser
- (void) parserDidStartDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidStartDocument");
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    if ([elementName isEqualToString:@"With_x0020_DateAnswerResult"]){
        check = YES;
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    if(check && [string isEqualToString:@"1"]){
        NSLog(@"submit successfully!");
        check = NO;
    }
}

- (void) parserDidEndDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidEndDocument");
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex;{
    
    // the user clicked "submit"
    if (buttonIndex == 1)
    {
        NSString *ans = [[alertView textFieldAtIndex:0] text];
        if([ans isEqualToString:@""]){
            [alertView show];
        }else{
            [self saveQuestion:ans];
        }
    }
}


@end
