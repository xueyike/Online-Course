//
//  Chapter.m
//  Online Course
//
//  Created by Yike Xue on 7/7/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "Chapter.h"



@implementation Chapter

@dynamic chapter_name;
@dynamic section_num;
@dynamic sections;

@end
