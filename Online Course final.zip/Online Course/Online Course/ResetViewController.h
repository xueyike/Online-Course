//
//  ResetViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResetViewController : UIViewController <NSXMLParserDelegate, UIAlertViewDelegate>

@property int validateduser;

@property (weak, nonatomic) IBOutlet UITextField *usernameInput;
@property (weak, nonatomic) IBOutlet UITextField *passwordInput;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;

- (IBAction)pressedReset:(id)sender;
- (IBAction)didEndOnExit:(id)sender;
@end
