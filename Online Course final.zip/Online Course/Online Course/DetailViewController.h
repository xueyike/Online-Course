//
//  DetailViewController.h
//  Online Course
//
//  Created by Yike Xue on 7/6/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "Section.h"
#import "Chapter.h"

@interface DetailViewController : UIViewController <NSXMLParserDelegate, UIAlertViewDelegate>{
    MPMoviePlayerController *moviePlayer;
}

@property (strong, nonatomic) Section *detailItem;
@property (weak, nonatomic) IBOutlet UIView *videoView;
@property (weak, nonatomic) IBOutlet UILabel *watchingLabel;
@property (weak, nonatomic) IBOutlet UIButton *journalButton;

@end

