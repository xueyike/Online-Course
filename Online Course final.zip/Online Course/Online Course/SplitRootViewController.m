//
//  SplitRootViewController.m
//  Online Course
//
//  Created by Yike Xue on 7/6/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "SplitRootViewController.h"
#import "NaviRootViewController.h"
#import "MasterViewController.h"

@interface SplitRootViewController ()

@end

@implementation SplitRootViewController

- (void)viewDidLoad {
    NaviRootViewController *navigationController = [self.viewControllers lastObject];
    navigationController.topViewController.navigationItem.leftBarButtonItem = self.displayModeButtonItem;
//    self.delegate = self;
    
    NaviRootViewController *masterNavigationController = self.viewControllers[0];
    MasterViewController *controller = (MasterViewController *)masterNavigationController.topViewController;
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    controller.managedObjectContext = appDelegate.managedObjectContext;
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

//// In a storyboard-based application, you will often want to do a little preparation before navigation
//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    // Get the new view controller using [segue destinationViewController].
//    // Pass the selected object to the new view controller.
//    NaviRootViewController *destination = segue.destinationViewController;
//    if ([destination respondsToSelector:@selector(setDelegate:)]) {
//        [destination setValue:self forKey:@"delegate"];
//    }
//    if ([destination respondsToSelector:@selector(setUserID:)]) {
//        [destination setValue:self.userID forKey:@"userID"];
//    }
//}


@end
