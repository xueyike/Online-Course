//
//  MasterViewController.m
//  Online Course
//
//  Created by Yike Xue on 7/6/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "MasterViewController.h"
#import "DetailViewController.h"
#import "Chapter.h"
#import "Section.h"

@interface MasterViewController ()

@end

@implementation MasterViewController{
    NSMutableArray *chapters;
}

@synthesize managedObjectContext;

- (void)awakeFromNib {
    [super awakeFromNib];
    self.clearsSelectionOnViewWillAppear = NO;
    self.preferredContentSize = CGSizeMake(320.0, 600.0);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.title = @"Videos";

    chapters = [NSMutableArray array];
    AppDelegate *appDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    managedObjectContext = appDelegate.managedObjectContext;
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc]
                                        initWithKey:@"chapter_name" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor,nil];
    [fetchRequest setSortDescriptors:sortDescriptors];
    NSEntityDescription *entity = [NSEntityDescription
                                   entityForName:@"Chapter" inManagedObjectContext:managedObjectContext];
    [fetchRequest setEntity:entity];
    NSError *error;
    NSArray *fetchedObjects = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    
    for(int i = 0; i < [fetchedObjects count]; i++){
        [chapters addObject:[fetchedObjects objectAtIndex:i]];
    }
//    for(Chapter *chapter in fetchedObjects){
//        [chapters addObject:chapter];
//    }
    
    if(chapters == nil || [chapters count] < 1){
        //add data to core data
        [self saveData];
    }
    self.detailViewController = (DetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
}

- (void)saveData {
    //According to the video we have, there are 4 chapters and 8(3,1,3,1) sections in total
    Chapter *chapter1 = [NSEntityDescription
                      insertNewObjectForEntityForName:@"Chapter"
                      inManagedObjectContext:managedObjectContext];
    chapter1.chapter_name = @"Chapter00";
    chapter1.section_num = [NSNumber numberWithInt:3];

    Section *s1 = [NSEntityDescription
                  insertNewObjectForEntityForName:@"Section"
                  inManagedObjectContext:managedObjectContext];
    s1.section_name = @"Section 1";
    s1.url = @"http://localhost/OnlineCourse/video/Chapter00/section1/Ch00S1List.m3u8";
    [s1 setValue:chapter1 forKey:@"chap"];
    Section *s2 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s2.section_name = @"Section 2";
    s2.url = @"http://localhost/OnlineCourse/video/Chapter00/section2/Ch00S2List.m3u8";
    [s2 setValue:chapter1 forKey:@"chap"];
    Section *s3 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s3.section_name = @"Section 3";
    s3.url = @"http://localhost/OnlineCourse/video/Chapter00/section3/Ch00S3List.m3u8";
    [s3 setValue:chapter1 forKey:@"chap"];
    
//    [chapter1 addSectionsObject:s1];
//    [chapter1 addSectionsObject:s2];
//    [chapter1 addSectionsObject:s3];
   
    [chapters addObject:chapter1];
    
    Chapter *chapter2 = [NSEntityDescription
                         insertNewObjectForEntityForName:@"Chapter"
                         inManagedObjectContext:managedObjectContext];
    chapter2.chapter_name = @"Chapter01";
    chapter2.section_num = [NSNumber numberWithInt:1];
    
    s1 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s1.section_name = @"Section 1";
    s1.url = @"http://localhost/OnlineCourse/video/Chapter01/section1/Ch01S1List.m3u8";
    [s1 setValue:chapter2 forKey:@"chap"];
    
//    [chapter2 addSectionsObject:s1];

    [chapters addObject:chapter2];
    
    
    Chapter *chapter3 = [NSEntityDescription
                         insertNewObjectForEntityForName:@"Chapter"
                         inManagedObjectContext:managedObjectContext];
    chapter3.chapter_name = @"Chapter02";
    chapter3.section_num = [NSNumber numberWithInt:3];
    
    s1 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s1.section_name = @"Section 1";
    s1.url = @"http://localhost/OnlineCourse/video/Chapter02/section1/Ch02S1List.m3u8";
    [s1 setValue:chapter3 forKey:@"chap"];
    s2 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s2.section_name = @"Section 2";
    s2.url = @"http://localhost/OnlineCourse/video/Chapter02/section2/Ch02S2List.m3u8";
    [s2 setValue:chapter3 forKey:@"chap"];
    s3 = [NSEntityDescription
                   insertNewObjectForEntityForName:@"Section"
                   inManagedObjectContext:managedObjectContext];
    s3.section_name = @"Section 3";
    s3.url = @"http://localhost/OnlineCourse/video/Chapter02/section3/Ch02S3List.m3u8";
    [s3 setValue:chapter3 forKey:@"chap"];
    
//    [chapter3 addSectionsObject:s1];
//    [chapter3 addSectionsObject:s2];
//    [chapter3 addSectionsObject:s3];
    
    [chapters addObject:chapter3];
    
    
    Chapter *chapter4 = [NSEntityDescription
                         insertNewObjectForEntityForName:@"Chapter"
                         inManagedObjectContext:managedObjectContext];
    chapter4.chapter_name = @"Chapter03";
    chapter4.section_num = [NSNumber numberWithInt:1];
    
    s1 = [NSEntityDescription
          insertNewObjectForEntityForName:@"Section"
          inManagedObjectContext:managedObjectContext];
    s1.section_name = @"Section 1";
    s1.url = @"http://localhost/OnlineCourse/video/Chapter03/section1/Ch03S1List.m3u8";
    [s1 setValue:chapter4 forKey:@"chap"];
    
//    [chapter4 addSectionsObject:s1];

    [chapters addObject:chapter4];
    
    NSError *error;
    if (![managedObjectContext save:&error]) {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (void)insertNewObject:(id)sender {
//    NSManagedObjectContext *context = [self.fetchedResultsController managedObjectContext];
//    NSEntityDescription *entity = [[self.fetchedResultsController fetchRequest] entity];
//    NSManagedObject *newManagedObject = [NSEntityDescription insertNewObjectForEntityForName:[entity name] inManagedObjectContext:context];
//        
//    // If appropriate, configure the new managed object.
//    // Normally you should use accessor methods, but using KVC here avoids the need to add a custom class to the template.
//    [newManagedObject setValue:[NSDate date] forKey:@"timeStamp"];
//        
//    // Save the context.
//    NSError *error = nil;
//    if (![context save:&error]) {
//        // Replace this implementation with code to handle the error appropriately.
//        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
//        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
//        abort();
//    }
//}

//#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        Chapter *ch = chapters[indexPath.section];
        Section *sec = ch.sections.array[indexPath.row];
        DetailViewController *controller = (DetailViewController *)[[segue destinationViewController] topViewController];
        [controller setDetailItem:sec];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
    }
}

#pragma mark - Table View
- ( CGFloat )tableView:( UITableView *)tableView heightForHeaderInSection:( NSInteger )section

{
    return 30.0 ;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [chapters count];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel *label = [ [ UILabel alloc ] initWithFrame: CGRectMake(0.0, 0.0, 85.0 , 30.0) ];
    
    label.text = [chapters[section] chapter_name];
    label.textColor = [UIColor whiteColor];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 40)];
    
    [header addSubview:label];
    return header;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [chapters[section] section_num].integerValue;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    //[self configureCell:cell atIndexPath:indexPath];
    cell.textLabel.text = [NSString stringWithFormat:@"Section %lu",indexPath.row+1];
    cell.textLabel.textColor = [UIColor lightGrayColor];
    cell.backgroundColor = [UIColor colorWithRed:42 green:89 blue:129 alpha:0.1];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return NO;
}

//- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        NSManagedObjectContext *context = [self.fetchedResultsController managedObjectContext];
//        [context deleteObject:[self.fetchedResultsController objectAtIndexPath:indexPath]];
//            
//        NSError *error = nil;
//        if (![context save:&error]) {
//            // Replace this implementation with code to handle the error appropriately.
//            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
//            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
//            abort();
//        }
//    }
//}
//
//- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
//    NSManagedObject *object = [self.fetchedResultsController objectAtIndexPath:indexPath];
//    cell.textLabel.text = [[object valueForKey:@"timeStamp"] description];
//}
//
//#pragma mark - Fetched results controller
//
//- (NSFetchedResultsController *)fetchedResultsController
//{
//    if (_fetchedResultsController != nil) {
//        return _fetchedResultsController;
//    }
//    
//    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
//    // Edit the entity name as appropriate.
//    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Event" inManagedObjectContext:self.managedObjectContext];
//    [fetchRequest setEntity:entity];
//    
//    // Set the batch size to a suitable number.
//    [fetchRequest setFetchBatchSize:20];
//    
//    // Edit the sort key as appropriate.
//    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"timeStamp" ascending:NO];
//    NSArray *sortDescriptors = @[sortDescriptor];
//    
//    [fetchRequest setSortDescriptors:sortDescriptors];
//    
//    // Edit the section name key path and cache name if appropriate.
//    // nil for section name key path means "no sections".
//    NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:@"Master"];
//    aFetchedResultsController.delegate = self;
//    self.fetchedResultsController = aFetchedResultsController;
//    
//	NSError *error = nil;
//	if (![self.fetchedResultsController performFetch:&error]) {
//	     // Replace this implementation with code to handle the error appropriately.
//	     // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development. 
//	    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
//	    abort();
//	}
//    
//    return _fetchedResultsController;
//}    
//
//- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller
//{
//    [self.tableView beginUpdates];
//}
//
//- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
//           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type
//{
//    switch(type) {
//        case NSFetchedResultsChangeInsert:
//            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
//            break;
//            
//        case NSFetchedResultsChangeDelete:
//            [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
//            break;
//            
//        default:
//            return;
//    }
//}
//
//- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
//       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
//      newIndexPath:(NSIndexPath *)newIndexPath
//{
//    UITableView *tableView = self.tableView;
//    
//    switch(type) {
//        case NSFetchedResultsChangeInsert:
//            [tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
//            break;
//            
//        case NSFetchedResultsChangeDelete:
//            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
//            break;
//            
//        case NSFetchedResultsChangeUpdate:
//            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
//            break;
//            
//        case NSFetchedResultsChangeMove:
//            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
//            [tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
//            break;
//    }
//}
//
//- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
//{
//    [self.tableView endUpdates];
//}

/*
// Implementing the above methods to update the table view in response to individual changes may have performance implications if a large number of changes are made simultaneously. If this proves to be an issue, you can instead just implement controllerDidChangeContent: which notifies the delegate that all section and object changes have been processed. 
 
 - (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    // In the simplest, most efficient, case, reload the table view.
    [self.tableView reloadData];
}
 */

@end
