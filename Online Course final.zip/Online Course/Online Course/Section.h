//
//  Section.h
//  Online Course
//
//  Created by Yike Xue on 7/7/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Chapter;

@interface Section : NSManagedObject

@property (nonatomic, retain) NSString * section_name;
@property (nonatomic, retain) NSString * url;
@property (nonatomic, retain) Chapter *chap;

@end
