//
//  NaviRootViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/29/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NaviRootViewController : UINavigationController

@property (copy, nonatomic) NSString *masterOrDetail;

@end
