//
//  Section.m
//  Online Course
//
//  Created by Yike Xue on 7/7/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "Section.h"
#import "Chapter.h"


@implementation Section

@dynamic section_name;
@dynamic url;
@dynamic chap;

@end
